//Sedikit penjelasan mengenai Javascript ini, jadi code js ini digunakan untuk menyortir apakah Task yang ditampilkan
//dalam Task HTML itu berdasarkan tanggal ataupun jenis kursusnya :)

function sortTasks(criteria) {
    let tasks = document.querySelectorAll('.task-card');
    let taskArray = Array.from(tasks);
    
    if (criteria === 'deadline') {
        taskArray.sort((a, b) => {
            let dateA = new Date(a.getAttribute('data-deadline'));
            let dateB = new Date(b.getAttribute('data-deadline'));
            return dateA - dateB;
        });
    } else if (criteria === 'course') {
        taskArray.sort((a, b) => {
            let courseA = a.getAttribute('data-course').toLowerCase();
            let courseB = b.getAttribute('data-course').toLowerCase();
            if (courseA < courseB) return -1;
            if (courseA > courseB) return 1;
            return 0;
        });
    }
    
    let taskList = document.getElementById('taskList');
    taskList.innerHTML = '';
    taskArray.forEach(task => {
        taskList.appendChild(task);
    });
}
